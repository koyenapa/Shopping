// https://leetcode.com/problems/magnetic-force-between-two-balls

class Solution {
public:
    bool ispossible(vector<int>&position,int m,int minDist){
        
            int count=1;
            int lastplaced=0;
            for(int i=0;i<position.size();i++){
                if(position[i]-lastplaced>=minDist){
                    count++;
                    lastplaced=position[i];
                }
            }if(count>=m){
                return true;
            }else 
                return false;
    }    
    int maxDistance(vector<int> position, int m) {
        int n=position.size();
        sort(position.begin(),position.end());
        int high=position[position.size()-1]-position[0];
        int low=position[0];
        int ans=0;
        while(low<=high){
            int mid=(low+high)/2;
             if(ispossible(position,m,mid)){
                 low=mid+1;
                 ans=mid;
             }else{
                 high=mid-1;
             }
        }
        return ans;
        
    }
};