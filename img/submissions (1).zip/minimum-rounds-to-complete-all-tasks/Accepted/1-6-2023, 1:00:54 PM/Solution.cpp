// https://leetcode.com/problems/minimum-rounds-to-complete-all-tasks

class Solution {
public:
    int minimumRounds(vector<int>& tasks) {
        unordered_map<int,int>mpp;
        for(auto num:tasks)
        {
            mpp[num]++;
        }int output=0;
        for(auto it:mpp)
        {
            if(it.second==1)return -1;
            if(it.second%3==0)
            {
                output+=(it.second/3);
            }else
            {
                output+=(it.second/3)+1;
            }
        }return output;
        
    }
};