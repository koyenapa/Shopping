// https://leetcode.com/problems/count-primes

class Solution {
public:
    int countPrimes(int n) {
        int c=0;int a=2;
        if(n==0||n==1)return 0;
        while(a!=n)
        {    int flag=0;
             for(int i=2;i<a;i++)
             {
                 if(a%i==0)
                 {
                     flag=1;
                     break;
                 }
             }
             if(flag==0)c++;
         a++;
        }
        return c;
    }
};