// https://leetcode.com/problems/maximum-product-subarray

class Solution {
public:
    int maxProduct(vector<int>& nums) {
         int ans = nums[0];
        int mi = nums[0];
        int ma = nums[0];
        for(int i=1; i<nums.size(); i++){
            if(nums[i] > 0){
                ma = max(nums[i], nums[i]*ma);
                mi = min(nums[i], mi*nums[i]);
            }
            else if(nums[i] == 0){
                ma = 0;
                mi = 0;
            }
            else{
                swap(ma, mi);
                mi = min(nums[i], mi*nums[i]);
                ma = max(nums[i],ma*nums[i]);
            }
            ans = max(ma, ans);
        }
        return ans;
        
    }
};