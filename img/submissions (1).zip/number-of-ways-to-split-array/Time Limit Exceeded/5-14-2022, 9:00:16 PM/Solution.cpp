// https://leetcode.com/problems/number-of-ways-to-split-array

class Solution {
public:
    int waysToSplitArray(vector<int>& nums) {
        int count=0,sum=0,sum2=0;
        int n=nums.size();
        for(int i=0;i<n-1;i++)
        {
            sum=sum+nums[i];
            sum2=0;
            for(int j=i+1;j<n;j++)
            {
                sum2=sum2+nums[j];
            }if(sum>=sum2)
                count++;
        }return count;
        
    }
};