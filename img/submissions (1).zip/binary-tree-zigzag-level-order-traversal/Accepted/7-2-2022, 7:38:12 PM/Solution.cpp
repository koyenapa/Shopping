// https://leetcode.com/problems/binary-tree-zigzag-level-order-traversal

/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode() : val(0), left(nullptr), right(nullptr) {}
 *     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
 *     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
 * };
 */
class Solution {
public:
    vector<vector<int>> zigzagLevelOrder(TreeNode* root) {
        vector<vector<int>>result;
        if(root==NULL)return result;
        queue<TreeNode*>nodesQueue;
        bool lefttoright=true;
        nodesQueue.push(root);
        while(!nodesQueue.empty())
        {
            int s=nodesQueue.size();
            vector<int>row (s);
            for(int i=0;i<s;i++)
            {
                TreeNode* node=nodesQueue.front();
                nodesQueue.pop();
                int index=(lefttoright)?i:s-i-1;
                row[index]=node->val;
                if(node->left!=NULL)
                {
                    nodesQueue.push(node->left);
                } if(node->right!=NULL)
                {
                    nodesQueue.push(node->right);
                } 
            }lefttoright=!lefttoright;
            result.push_back(row);   
            
            
        }
        return result;
        
    }
};