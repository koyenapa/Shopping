// https://leetcode.com/problems/maximum-bags-with-full-capacity-of-rocks

class Solution {
public:
    int maximumBags(vector<int>& capacity, vector<int>& rocks, int additionalRocks) {
        int c=0;int n=capacity.size();
        for(int i=0;i<n;i++)
        {
            if(capacity[i]!=rocks[i])
            {
                if((capacity[i]-rocks[i])<=additionalRocks)
                {
                    rocks[i]=capacity[i]-rocks[i];
                    additionalRocks-=capacity[i]-rocks[i];
                    c++;
                }
            }
        }return c+1;
        
    }
};