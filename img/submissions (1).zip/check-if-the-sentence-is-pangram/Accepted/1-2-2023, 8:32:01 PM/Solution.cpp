// https://leetcode.com/problems/check-if-the-sentence-is-pangram

class Solution {
public:
    bool checkIfPangram(string sentence) {
        vector<int>freq(26);
        for(auto &s:sentence)
        {
            freq[s-'a']++;
        }for(auto it:freq)
        if(it==0)
        return false;
        return true;
    }
};