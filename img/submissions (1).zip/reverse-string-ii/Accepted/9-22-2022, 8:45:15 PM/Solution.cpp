// https://leetcode.com/problems/reverse-string-ii

class Solution {
public:
    string reverseStr(string s, int k) {
        int st=0;int size=s.length();;
        while(st<s.length())
        {
            if((size-st)<k)
            {
                int i=st;
                int j=s.length()-1;
                while(i<=j)
                {
                    swap(s[i],s[j]);
                    i++;j--;
                }
                st=s.length();
            }else
            {
                int i=st;
                int j=st+k-1;
                while(i<=j)
                {
                    swap(s[i],s[j]);
                    i++;j--;
                }
            }
            st=st+(2*k);
            
        }
        return s;
        
    }
};