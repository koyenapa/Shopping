// https://leetcode.com/problems/set-mismatch

class Solution {
public:
    vector<int> findErrorNums(vector<int>& nums) {
        vector<int>ans;
        int n=nums.size();int i=0;
        while(i<n)
        {
            if(nums[nums[i]-1]!=nums[i])
            {
                swap(nums[nums[i]-1],nums[i]);
            }else
            {
                i++;
            }
        }for(int j=0;j<n;j++)
        {
            if(nums[j]!=j+1)
            {
                ans.push_back(nums[j]);
                ans.push_back(j+1);
            }
        }
        return ans;
        
    }
};