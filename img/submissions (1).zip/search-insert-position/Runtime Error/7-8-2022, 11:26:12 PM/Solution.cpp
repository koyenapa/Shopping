// https://leetcode.com/problems/search-insert-position

class Solution {
public:
    int searchInsert(vector<int>& nums, int target) {
        int slow=0,high=nums.size()-1;
        int flag=0;
        while(slow<=high)
        {
            int mid=(slow+high)/2;
            if(nums[mid]==target)
            {    flag=1;
                return mid;
            }
            else if(nums[mid]<target)
            {
                slow=mid+1;
            }else high=mid-1;
        }
        int c=0;
        if(flag==0)
        {
            for(int i=0;i<nums.size();i++)
                if(nums[i]<target&&nums[i+1]>target)return i+1;
        }
        return nums.size();
        
    }
};