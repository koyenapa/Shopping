// https://leetcode.com/problems/reverse-words-in-a-string

class Solution {
public:
    string reverseWords(string s) {
        vector<string>v;
        stringstream st(s);
        string word;
        while(st>>word)
        {
            v.push_back(word);
        }string ans;
        for(int i=v.size()-1;i>=0;i--)
        {
            if(i!=v.size()-1)ans+=" ";
            ans+=v[i];
        }return ans;
    }
};