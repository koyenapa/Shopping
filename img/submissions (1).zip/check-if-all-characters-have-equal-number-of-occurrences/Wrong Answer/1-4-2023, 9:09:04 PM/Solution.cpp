// https://leetcode.com/problems/check-if-all-characters-have-equal-number-of-occurrences

class Solution {
public:
    bool areOccurrencesEqual(string s) {
        int ans=0;
        for(char &c:s)
        {
            ans^=c-'0';
        }if(ans==0)return true;
        return false;
        
    }
};