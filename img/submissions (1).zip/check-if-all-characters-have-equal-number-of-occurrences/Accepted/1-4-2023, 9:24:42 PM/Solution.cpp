// https://leetcode.com/problems/check-if-all-characters-have-equal-number-of-occurrences

class Solution {
public:
    bool areOccurrencesEqual(string s) {
        int freq[26]={};
        for(int i=0;i<s.size();i++)
        {
            freq[s[i]-97]++;
        }
        int x=freq[s[0]-97];
        for(int i=0;i<26;i++)
        {
            if(x!=freq[i] && freq[i]!=0)return false;
        }return true;

        
    }
};