// https://leetcode.com/problems/number-of-zero-filled-subarrays

class Solution {
public:
    long long zeroFilledSubarray(vector<int>& nums) {
        long long c=0;
        for(long long i=0;i<nums.size();i++)
        {
            for(long long j=i;j<nums.size();j++)
            {
                if(nums[j]==nums[i])c++;
            }
        }return c;
        
    }
};