// https://leetcode.com/problems/kids-with-the-greatest-number-of-candies

class Solution {
public:
    vector<bool> kidsWithCandies(vector<int>& digits, int extraCandies) {
        vector<bool>ans;
        int n=digits.size();int j=0;
        while(j!=n)
        {
            int f=0;
            int ma=digits[j]+extraCandies;
            for(int i=0;i<n;i++)
            {
                if(ma<digits[i])
               {
                   f=1;break;
                   
               }
            }if(f==1)ans.push_back(0);
            else ans.push_back(1);
            j++;
        }
        return ans;
    }
};