// https://leetcode.com/problems/missing-number

class Solution {
public:
    int missingNumber(vector<int>& nums) {
        int n=nums.size();
        int k=(n*(n+1))/2;
        int sum=0;
        for(auto x:nums)
        {
            sum=sum+x;
        }return k-sum;
    }
};