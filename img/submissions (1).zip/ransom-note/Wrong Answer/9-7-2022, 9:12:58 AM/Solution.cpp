// https://leetcode.com/problems/ransom-note

class Solution {
public:
    bool canConstruct(string ransomNote, string magazine) {
        int k=magazine.size()-ransomNote.size();
        int flag=0;
        for(int i=0;i<=k;i++)
        {
            if(ransomNote[i]!=magazine[i])return false;
            if(ransomNote[i]==magazine[i])
            {
                flag=1;
            }
        }
        if(flag==1)
            return true;
     return false;   
    }
};