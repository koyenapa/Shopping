// https://leetcode.com/problems/richest-customer-wealth

class Solution {
public:
    int maximumWealth(vector<vector<int>>& accounts) {
        int ma=INT_MIN;
        for(auto nums:accounts)
        {
            int sum=0;
            for(auto num:nums)
            {
                sum+=num;
            }ma=max(ma,sum);
        }return ma;
    }
};