// https://leetcode.com/problems/average-of-levels-in-binary-tree

/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode() : val(0), left(nullptr), right(nullptr) {}
 *     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
 *     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
 * };
 */
class Solution {
public:
    vector<double> averageOfLevels(TreeNode* root) {
        if(root==NULL)return {0.0};
        queue<TreeNode*>q;
        vector<double>level;
        q.push({root});
        while(!q.empty())
        {
            int s=q.size();
            double level_sum=0.0;
            for(int i=0;i<s;i++)
            {
                TreeNode* node=q.front();
                level_sum+=node->val;
                q.pop();
                if(node->left!=NULL)q.push({node->left});
                if(node->right!=NULL)q.push({node->right});
            }
            level.push_back(level_sum/s);    
        }
        return level;
        
    }
};