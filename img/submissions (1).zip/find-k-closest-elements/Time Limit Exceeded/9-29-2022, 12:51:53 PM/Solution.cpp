// https://leetcode.com/problems/find-k-closest-elements

class Solution {
public:
    vector<int> findClosestElements(vector<int>& arr, int k, int x) {
        int n=arr.size();
        if(n==1)return {1};
        int low=0;
        vector<int>ans;
        while(ans.size()!=k)
        {
            if(abs(arr[low]-x)<abs(arr[n-1]-x))
            {
                ans.push_back(arr[low]);
                low++;
            }else if(abs(arr[low]-x)==abs(arr[n-1]-x)&&arr[low]<arr[n-1])
            {
                ans.push_back(arr[low]);
                low++;
            }
        }
        return ans;
    }
};