// https://leetcode.com/problems/find-k-closest-elements

class Solution {
public:
    vector<int> findClosestElements(vector<int>& arr, int k, int x) {
        int n=arr.size();
        int low=0;int high=n-1;
        vector<int>ans;
        while(ans.size()!=k)
        {
            if(abs(arr[low]-x)<abs(arr[high]-x))
            {
                ans.push_back(arr[low]);
                low++;
            }else if(abs(arr[low]-x)==abs(arr[high]-x)&&arr[low]<arr[high])
            {
                ans.push_back(arr[low]);
                low++;
            }
        }
        return ans;
    }
};