// https://leetcode.com/problems/path-sum-ii

/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode() : val(0), left(nullptr), right(nullptr) {}
 *     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
 *     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
 * };
 */
class Solution {
public:
    void pathsum(TreeNode* root,vector<int> ds,vector<vector<int>>&ans,int targetsum)
    {
        if(root==NULL)return;
        ds.push_back(root->val);
        int sum=targetsum-root->val;
        if(sum==0 && root->left==NULL && root->right==NULL)
        {
            ans.push_back(ds);
            return;
        }
        pathsum(root->left,ds,ans,sum);
        pathsum(root->right,ds,ans,sum);
        
    }
    
    vector<vector<int>> pathSum(TreeNode* root, int targetSum) {
        vector<vector<int>>ans;
        vector<int>temp;
        pathsum(root,temp,ans,targetSum);
        return ans;
        
    }
};