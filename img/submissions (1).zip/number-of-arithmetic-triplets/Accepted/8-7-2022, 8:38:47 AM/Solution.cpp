// https://leetcode.com/problems/number-of-arithmetic-triplets

class Solution {
public:
    int arithmeticTriplets(vector<int>& nums, int diff) {
        map<int,int>mpp;
        int c=0;
        for(int i=0;i<nums.size();i++)
        {
            mpp[nums[i]]++;
        }for(int i=0;i<nums.size();i++){
            if(mpp.find(nums[i]-diff)!=mpp.end()&&mpp.find(nums[i]+diff)!=mpp.end())
                c++;
        }return c;
        
    }
};