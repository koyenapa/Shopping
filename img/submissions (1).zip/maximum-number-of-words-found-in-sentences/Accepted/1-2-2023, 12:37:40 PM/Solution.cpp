// https://leetcode.com/problems/maximum-number-of-words-found-in-sentences

class Solution {
public:
    int mostWordsFound(vector<string>& sentences) {
        int ma=INT_MIN;
        for(int i=0;i<sentences.size();i++)
        {
            int c=0;
            stringstream st(sentences[i]);
            string word;
            while(st>>word)
            {
                c++;
            }ma=max(c,ma);
        }return ma;
        
    }
};