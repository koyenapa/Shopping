// https://leetcode.com/problems/number-of-good-pairs

class Solution {
public:
    int numIdenticalPairs(vector<int>& nums) {
        int cnt=0;
        map<int,int>mpp;
        for(auto num:nums)
        {
            cnt+=mpp[num];
            ++mpp[num];
            
        }return cnt;
        
    }
};