// https://leetcode.com/problems/find-the-middle-index-in-array

class Solution {
public:
    int findMiddleIndex(vector<int>& arr) {
         int sum=0;
        int leftsum=0;
        for(int num:arr)sum+=num;
        for(int i=0;i<arr.size();i++)
        {
            if(leftsum==sum-leftsum-arr[i])return i;
            leftsum+=arr[i];
        }
        return -1;

    }
};