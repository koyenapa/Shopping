// https://leetcode.com/problems/subarray-sum-equals-k

class Solution {
public:
    int subarraySum(vector<int>& nums, int k) {
        int sum=0;
        int c=0;int j=0;int i=0;
        while(j<nums.size())
        {
            sum=sum+nums[j];
            if(sum<k)j++;
            else if(sum==k){
                c++;
                j++;
            }    
            else if(sum>k)
            {
               while(sum>k)
               {
                   sum=sum-nums[i];
                   i++;
               }if(sum==k)c++;
                j++;
            }
            
        }return c;
        
    }
};