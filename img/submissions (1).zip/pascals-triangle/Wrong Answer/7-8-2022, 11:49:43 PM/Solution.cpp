// https://leetcode.com/problems/pascals-triangle

class Solution {
public:
    vector<vector<int>> generate(int numRows) {
        vector<vector<int>>ans;
        for(int i=0;i<numRows;i++)
        {
           vector<int>result;
           int prod=pow(11,i);
           while(prod!=0)
           {
               int r=prod%10;
               if(r==0)result.push_back(prod);
               else
               result.push_back(r);
               prod=prod/10;
           }ans.push_back(result); 
        }
        return ans;
    }
};