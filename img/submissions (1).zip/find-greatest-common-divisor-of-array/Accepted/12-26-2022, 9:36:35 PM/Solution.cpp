// https://leetcode.com/problems/find-greatest-common-divisor-of-array

class Solution {
public:
    int findGCD(vector<int>& arr) {
        int ma=arr[0];int min=arr[0];
        for(int i=0;i<arr.size();i++)
        {
            if(ma<arr[i])ma=arr[i];
            if(min>arr[i])min=arr[i];
        }int c=INT_MIN;
        for(int i=1;i<=ma;i++)
        {
            if(min%i==0 && ma%i==0)
            {
                c=max(i,c);
            }
        }return c;
    }
};