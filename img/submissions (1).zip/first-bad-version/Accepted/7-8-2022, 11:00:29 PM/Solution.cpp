// https://leetcode.com/problems/first-bad-version

// The API isBadVersion is defined for you.
// bool isBadVersion(int version);

class Solution {
public:
    int firstBadVersion(int n) {

    if( n == 1 )
        return 1;
    return find( 1, n );
    
}

int find( int start, int end ) {
    
    while( start <= end ) {
        
        int mid = start + ( end - start ) / 2;
        
        if( mid == 1 and isBadVersion( mid ) ) {
            
            return mid;
            
        }
        else if( mid > 1 and isBadVersion( mid ) and !isBadVersion( mid - 1 ) ) {
        
            return mid;
            
        }
        else if( mid > 1 and isBadVersion( mid ) and isBadVersion( mid - 1 ) ){
            
            return find( start, mid );
            
        }
        else {
            
            return find( mid + 1, end );
            
        }
        
    }
    
    return 0;
    
}
};