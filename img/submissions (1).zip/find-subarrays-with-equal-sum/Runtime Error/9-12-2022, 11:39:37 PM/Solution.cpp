// https://leetcode.com/problems/find-subarrays-with-equal-sum

class Solution {
public:
    bool findSubarrays(vector<int>& nums) {
        unordered_map<int,int>mpp;
        for(int i=0;i<nums.size();i++)
        {
            if(mpp[nums[i]+nums[i+1]]!=0)
            {
                return true;
            }mpp[nums[i]+nums[i+1]]++;
        }
        return false;
    }
};