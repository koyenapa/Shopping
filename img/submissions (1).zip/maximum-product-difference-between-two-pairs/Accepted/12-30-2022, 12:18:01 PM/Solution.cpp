// https://leetcode.com/problems/maximum-product-difference-between-two-pairs

class Solution {
public:
    int maxProductDifference(vector<int>& nums) {
       int ma=INT_MIN;
       int ma2=INT_MIN;
       int mi=INT_MAX;
       int mi2=INT_MAX;
       for(int i=0;i<nums.size();i++)
       {
           if(nums[i]>ma)
           {
               ma2=ma;
               ma=nums[i];
           }
           else if(nums[i]>ma2)
           {
               ma2=nums[i];
           }if(nums[i]<mi)
           {
               mi2=mi;
               mi=nums[i];
           }
           else if(nums[i]<mi2)
           {
               mi2=nums[i];
           }
       }
       return ((ma*ma2)-(mi*mi2));
        
    }
};