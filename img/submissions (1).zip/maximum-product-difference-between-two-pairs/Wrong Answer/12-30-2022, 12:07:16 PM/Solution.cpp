// https://leetcode.com/problems/maximum-product-difference-between-two-pairs

class Solution {
public:
    int maxProductDifference(vector<int>& nums) {
       int ma=nums[0];
       int ma2=nums[1];
       for(int i=0;i<nums.size();i++)
       {
           if(ma<nums[i])
           ma=nums[i];
       }
       for(int i=0;i<nums.size();i++)
       {
           if(nums[i]<ma&&nums[i]>ma2)
           {
               ma2=nums[i];
           }
       }
       int mi=nums[0];
       int mi2=nums[0];

       for(int i=0;i<nums.size();i++)
       {
           if(mi>nums[i])
           mi=nums[i];
       }cout<<mi;
       for(int i=0;i<nums.size();i++)
       {
           if(nums[i]>mi && nums[i]<mi2)
           {
               mi2=nums[i];
           }
       }cout<<mi2;
       return ((ma*ma2)-(mi*mi2));
        
    }
};