// https://leetcode.com/problems/jewels-and-stones

class Solution {
public:
    int numJewelsInStones(string jewels, string stones) {
        int c=0;
        map<char,int>mpp;
        for(int i=0;i<jewels.size();i++)
        {
            mpp[jewels[i]]=i;
        }for(int i=0;i<stones.size();i++)
        {
            if(mpp.find(stones[i])!=mpp.end())c++;
        }
        return c;
    }
};