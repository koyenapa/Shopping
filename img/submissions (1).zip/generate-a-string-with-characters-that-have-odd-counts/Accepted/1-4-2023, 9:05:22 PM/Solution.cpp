// https://leetcode.com/problems/generate-a-string-with-characters-that-have-odd-counts

class Solution {
public:
    string generateTheString(int n) {
        return "b" + string(n - 1, 'a' + n % 2);
    }
};