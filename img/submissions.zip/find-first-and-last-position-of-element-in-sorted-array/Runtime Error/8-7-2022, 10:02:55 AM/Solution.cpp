// https://leetcode.com/problems/find-first-and-last-position-of-element-in-sorted-array

class Solution {
public:
    vector<int> searchRange(vector<int>& nums, int target) {
        vector<int>ans;
        int flag=0;int end=0,count=0;                                
        for(int i=0;i<nums.size();i++)
        {
            if(nums[i]==target)
            {
                ans.push_back(i);
                int j=i+1;
                while(nums[j]==target)
                {
                    ans.push_back(j); 
                    j++;
                    flag=1;
                 }
                i++;
            }
        }
         if(flag==0)
         {
            ans.push_back(-1);
            ans.push_back(-1);    
         }return ans;
    }
};