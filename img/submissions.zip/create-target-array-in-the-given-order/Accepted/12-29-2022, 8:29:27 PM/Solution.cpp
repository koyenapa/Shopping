// https://leetcode.com/problems/create-target-array-in-the-given-order

class Solution {
public:
    vector<int> createTargetArray(vector<int>& nums, vector<int>& index) {
        vector<int>ans;
        for(int i=0;i<index.size();i++)
        {
            ans.insert(ans.begin()+index[i],nums[i]);
        }
        return ans;
    }
};