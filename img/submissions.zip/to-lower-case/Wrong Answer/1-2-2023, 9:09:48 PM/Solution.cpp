// https://leetcode.com/problems/to-lower-case

class Solution {
public:
    string toLowerCase(string s) {
        for(int i=0;i<s.size();i++)
        {
            if((s[i]-'a')<0)
            {
                s[i]=s[i]+32;
            }
        }return s;
    }
};