// https://leetcode.com/problems/number-of-common-factors

class Solution {
public:
    int commonFactors(int a, int b) {
        int i=1,c=0;
        while(i!=a)
        {
            if(a%i==0 && b%i==0)
            {
                c++;
            }if(a==b)c++;
            i++;
        }return c;
        
    }
};