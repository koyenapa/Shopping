// https://leetcode.com/problems/average-of-levels-in-binary-tree

/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode() : val(0), left(nullptr), right(nullptr) {}
 *     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
 *     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
 * };
 */
class Solution {
public:
    double average(vector<int>nums)
    {
        double sum=0.0;
        for(int v:nums)
        {
            sum=sum+v;
            
        }return sum/nums.size();
    }
    vector<double> averageOfLevels(TreeNode* root) {
        if(root==NULL)return {0.0};
        queue<TreeNode*>q;
        vector<double>level;
        q.push({root});
        while(!q.empty())
        {
            int s=q.size();
            vector<int>ans;
            for(int i=0;i<s;i++)
            {
                TreeNode* node=q.front();
                q.pop();
                if(node->left!=NULL)q.push({node->left});
                if(node->right!=NULL)q.push({node->right});
                ans.push_back(node->val);
            }double avg=average(ans);
            level.push_back(avg);    
        }
        return level;
        
    }
};