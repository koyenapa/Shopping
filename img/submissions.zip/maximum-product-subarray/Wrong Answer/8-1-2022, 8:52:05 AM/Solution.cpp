// https://leetcode.com/problems/maximum-product-subarray

class Solution {
public:
    int maxProduct(vector<int>& nums) {
        int ans=nums[0];
        int mi=ans;
        int ma=ans;
        for(int i=1;i<nums.size();i++)
        {
            if(nums[i]<0)
            {
               int temp=ma;
                ma=mi;
                mi=temp;
            }ma=(nums[i],ma*nums[i]);
            mi=(nums[i],mi*nums[i]);
            ans=max(ans,ma);
        }return ans;
        
    }
};