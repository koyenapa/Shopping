// https://leetcode.com/problems/sum-of-all-odd-length-subarrays

class Solution {
public:
    int sumOddLengthSubarrays(vector<int>& arr) {
        int i=0;int n=arr.size();int s=0;
        for(int i=0;i<n;i++)
        {
            s+=(((n-i)*(i+1)+1)/2)*arr[i];
        }    
        return s;

    }
};