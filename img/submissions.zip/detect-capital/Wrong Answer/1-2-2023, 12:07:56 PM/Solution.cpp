// https://leetcode.com/problems/detect-capital

class Solution {
public:
    bool detectCapitalUse(string word) {
        int c=0,k=0;
        for(int i=0;i<word.size();i++)
        {
            if(isupper(word[i]))
            {
                c++;
            }if(islower(word[i]))
            {
                k++;
            }
        }if(c==word.size())return true;
        if(c==1 && k==word.size()-1)return true;
        return false;
    }
};