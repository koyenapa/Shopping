// https://leetcode.com/problems/remove-outermost-parentheses

class Solution {
public:
    string removeOuterParentheses(string str) {
        string temp;int count=0;
        for(int i=0;i<str.size();i++)
        {
            if(str[i]=='(' && count==0)
            {
                count++;
                temp+='(';
            }else if(str[i]=='(' && count>=1)
            {
                count++;
            }else if(str[i]==')' && count>=1)
            {
                temp+=')';
                count--;
            }
            else if(str[i]==')'&& count==0)
            {
                count--;
            }
        }return temp;
    }
};