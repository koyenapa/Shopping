// https://leetcode.com/problems/word-subsets

class Solution {
public:
    vector<string> wordSubsets(vector<string>& words1, vector<string>& words2) {
        vector<string>ans;
        vector<int>freq1(26,0);
        for(int i=0;i<words2.size();i++)
        {
            vector<int>temp(26,0);
            string current=words2[i];
            for(auto ch:current)
            {
                temp[ch-'a']++;
                freq1[ch-'a']=max(freq1[ch-'a'],temp[ch-'a']);
            }
            
        }
        for(int i=0;i<words1.size();i++)
        {
            vector<int>freq2(26,0);
            int flag=0;
            string current=words1[i];
            for(auto ch:current)
            {
                freq2[ch-'a']++;
            }for(int i=0;i<26;i++)
            {
                if(freq1[i]>freq2[i])
                {
                    flag=1;
                    break;
                }
            
            }if(flag==0)
            {
                ans.push_back(current);
            }
        }return ans;
    }
};