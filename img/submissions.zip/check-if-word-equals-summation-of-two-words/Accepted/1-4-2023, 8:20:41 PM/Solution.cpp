// https://leetcode.com/problems/check-if-word-equals-summation-of-two-words

class Solution {
public:
    bool isSumEqual(string firstword, string secondword, string targetword) {
        
        for(auto &c:firstword)c-='a'-'0';
        for(auto &c:secondword)c-='a'-'0';
        for(auto &c:targetword)c-='a'-'0';
        return stoi(firstword)+stoi(secondword)==stoi(targetword);

    }
};