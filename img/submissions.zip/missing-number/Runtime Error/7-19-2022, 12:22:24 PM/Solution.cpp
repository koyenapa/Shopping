// https://leetcode.com/problems/missing-number

class Solution {
public:
    int missingNumber(vector<int>& nums) {
        sort(nums.begin(),nums.end());
        for(int i=0;i<nums.size();i++)
        {
            int diff=nums[i+1]-nums[i];
            if(diff>1)
                return i+1;
        }
        return -1;
        
    }
};