// https://leetcode.com/problems/numbers-with-same-consecutive-differences

class Solution {
public:
    void dfs(int num,int digit,int n,int k,vector<int>&res)
    {
        if(digit==n)
        {
            res.push_back(num);
            return;
        }
        
            for(int i=0;i<=9;i++)
            {
                int last_digit=num%10;
                if(abs(last_digit-i)==k)
                {
                    dfs(num*10+i,digit+1,n,k,res);
                }
            }
        
    }
    vector<int> numsSameConsecDiff(int n, int k) {
        vector<int>res;
        for(int i=1;i<=9;i++)
        {
            dfs(i,1,n,k,res);
        }
        return res;
        
    }
};