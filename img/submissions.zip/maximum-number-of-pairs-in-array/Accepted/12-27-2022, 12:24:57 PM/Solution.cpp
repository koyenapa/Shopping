// https://leetcode.com/problems/maximum-number-of-pairs-in-array

class Solution {
public:
    vector<int> numberOfPairs(vector<int>& nums) {
        sort(nums.begin(),nums.end());
        int i=1;
        int cnt=0;
        while(i<nums.size())
        {
            if(nums[i]==nums[i-1])
            {
                cnt++;
                i=i+2;
            }else
            {
                i++;
            }
        }int temp=nums.size()-2*cnt;
        return {cnt,temp};
    }
};