// https://leetcode.com/problems/rotate-array

class Solution {
public:
    void rotate(vector<int>& nums, int k) {
        int n=nums.size();
        int high=n-k-1;
        int low=0;
        while(low<high)
        {
            int t=nums[low];
            nums[low]=nums[high];
            nums[high]=t;
            low++;
            high--;
        }
        low=n-k;
        high=n-1;
        while(low<high)
        {
            int t=nums[low];
            nums[low]=nums[high];
            nums[high]=t;
            low++;
            high--;
        } low=0;
          high=n-1;
        while(low<high)
        {
            int t=nums[low];
            nums[low]=nums[high];
            nums[high]=t;
            low++;
            high--;
        }
        
    }
};