// https://leetcode.com/problems/binary-search

class Solution {
public:
    int search(vector<int>& nums, int target) {
        int slow=0,high=nums.size()-1;
        while(slow<=high)
        {
            int mid=(slow+high)/2;
            if(nums[mid]==target)
                return mid;
            else if(nums[mid]<target)
            {
                slow=mid+1;
            }else high=mid-1;
        }
        return -1;
        
    }
};