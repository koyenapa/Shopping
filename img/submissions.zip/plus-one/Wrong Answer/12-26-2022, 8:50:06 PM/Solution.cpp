// https://leetcode.com/problems/plus-one

class Solution {
public:
    vector<int> plusOne(vector<int>& digits) {
       int f=0;int n=digits.size();
       for(int i=n-1;i>=0;i--)
       {
           if(digits[i]<9)
           {
               digits[i]=digits[i]+1;
               break;
           }else
           {
               digits[i]=0;
               f=1;
           }
       }if(f==1)
       {
           digits.insert(digits.begin(),1);
       }return digits; 
       
        
    }
};