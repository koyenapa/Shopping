// https://leetcode.com/problems/maximum-bags-with-full-capacity-of-rocks

class Solution {
public:
    int maximumBags(vector<int>& capacity, vector<int>& rocks, int additionalRocks) {
        for(int i=0;i<capacity.size();i++)
        {
            capacity[i]=capacity[i]-rocks[i];
        }
        sort(capacity.begin(),capacity.end());
        int ans=0;
        for(int num=0;num<capacity.size();num++)
        {
            ans+=capacity[num];
            if(ans>additionalRocks)return num;
        }
        return capacity.size();
    }
};