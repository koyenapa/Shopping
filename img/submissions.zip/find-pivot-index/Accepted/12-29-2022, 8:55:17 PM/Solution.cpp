// https://leetcode.com/problems/find-pivot-index

class Solution {
public: 
    int pivotIndex(vector<int>& arr) {
        int sum=0;
        int leftsum=0;
        for(int num:arr)sum+=num;
        for(int i=0;i<arr.size();i++)
        {
            if(leftsum==sum-leftsum-arr[i])return i;
            leftsum+=arr[i];
        }
        return -1;

    }
};