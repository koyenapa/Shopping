// https://leetcode.com/problems/palindrome-linked-list

/**
 * Definition for singly-linked list.
 * struct ListNode {
 *     int val;
 *     ListNode *next;
 *     ListNode() : val(0), next(nullptr) {}
 *     ListNode(int x) : val(x), next(nullptr) {}
 *     ListNode(int x, ListNode *next) : val(x), next(next) {}
 * };
 */
class Solution {
public:
    ListNode* middle(ListNode* head)
    {
        ListNode* s=head;
        ListNode* f=head;
        while(f!=NULL&&f->next!=NULL)
        {
            s=s->next;
            f=f->next->next;
        }return s->next;   
    }ListNode* reverse(ListNode* head)
    {
        ListNode* curr=middle(head);
        ListNode* prev=NULL;
        ListNode* nex;
        while(curr!=NULL)
        {
            nex=curr->next;
            curr->next=prev;
            prev=curr;
            curr=nex;   
        }return prev;
    }
    bool isPalindrome(ListNode* head) {
        if(head==NULL||head->next==NULL)return true;
        ListNode* f=head;
        ListNode* t=reverse(head);
        while(t!=NULL)
        {
            if(f->val!=t->val)
                return false;
            t=t->next;
            f=f->next;   
        }return true;
        
    }
};