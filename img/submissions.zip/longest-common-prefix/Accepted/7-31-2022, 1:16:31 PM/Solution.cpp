// https://leetcode.com/problems/longest-common-prefix

class Solution {
public:
    string longestCommonPrefix(vector<string>& strs) {
        string ans=strs[0];
        for(int i=1;i<strs.size();i++)
        {
            string temp=strs[i];
            int n=temp.size();
            if(temp.size()<ans.size())n=ans.size();
            for(int i=0;i<n;i++)
            {
                if(temp[i]==ans[i])continue;
                else
                {
                    ans.erase(i);
                    break;
                }
            }
        }return ans;
        
    }
};