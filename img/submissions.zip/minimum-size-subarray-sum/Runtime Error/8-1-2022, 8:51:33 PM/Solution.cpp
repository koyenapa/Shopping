// https://leetcode.com/problems/minimum-size-subarray-sum

class Solution {
public:
    int minSubArrayLen(int target, vector<int>& nums) {
        unordered_map<int,int>mpp;
        int mi=INT_MAX;int sum=0;int c=0;
        for(int i=0;i<nums.size();i++)
        {
            sum=sum+nums[i];
            if(sum==target)return 0;
            if(mpp.find(target-sum)!=mpp.end())
            {
                c++;
                mi=min(mi,c);
            }
            mpp[nums[i]]++;
        }cout<<mi;
        return mi+1;
    }
};