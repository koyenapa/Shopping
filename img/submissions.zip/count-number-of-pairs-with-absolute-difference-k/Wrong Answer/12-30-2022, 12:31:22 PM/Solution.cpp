// https://leetcode.com/problems/count-number-of-pairs-with-absolute-difference-k

class Solution {
public:
    int countKDifference(vector<int>& nums, int k) {
        map<int,int>mpp;int cnt=0;
        for(int i=0;i<nums.size();i++)
        {
            mpp[nums[i]]++;
        }for(int i=0;i<nums.size()-1;i++)
        {
            if(mpp.find(abs(nums[i]-k))!=mpp.end())
            {
                cnt+=mpp[nums[i]];
                cout<<cnt;

            }
        }return cnt;
    }
};