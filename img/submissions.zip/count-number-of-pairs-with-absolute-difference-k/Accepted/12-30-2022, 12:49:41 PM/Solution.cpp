// https://leetcode.com/problems/count-number-of-pairs-with-absolute-difference-k

class Solution {
public:
    int countKDifference(vector<int>& nums, int k) {
        map<int,int>mpp;int cnt=0;
        for(int i=0;i<nums.size();i++)
        {
            cnt+=mpp[nums[i]-k]+mpp[nums[i]+k];
            mpp[nums[i]]++;
        }return cnt;
    }
};