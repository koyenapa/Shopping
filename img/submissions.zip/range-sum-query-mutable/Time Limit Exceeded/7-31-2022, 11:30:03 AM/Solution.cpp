// https://leetcode.com/problems/range-sum-query-mutable

class NumArray {
public:
    vector<int>v;
    NumArray(vector<int>& nums) {
        v=nums;
    }
    
    void update(int index, int val) {
        v[index]=val;
        
    }
    
    int sumRange(int left, int right) {
        int sum=0;
        for(int i=left;i<=right;i++)
        {
            sum+=v[i];
        }return sum;
        
    }
};

/**
 * Your NumArray object will be instantiated and called as such:
 * NumArray* obj = new NumArray(nums);
 * obj->update(index,val);
 * int param_2 = obj->sumRange(left,right);
 */