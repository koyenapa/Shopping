// https://leetcode.com/problems/check-if-two-string-arrays-are-equivalent

class Solution {
public:
    bool arrayStringsAreEqual(vector<string>& word1, vector<string>& word2) {
        string s,k;
        for(int i=0;i<word1.size();i++)
        {
            s+=word1[i];
        }
        for(auto i:word2)
        {
            k+=i;
        }if(s.compare(k)==0)return 1;
        else return 0;
        
    }
};