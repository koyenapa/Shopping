// https://leetcode.com/problems/check-if-two-string-arrays-are-equivalent

class Solution {
public:
    bool arrayStringsAreEqual(vector<string>& word1, vector<string>& word2) {
        string s="";string k="";int flag=0;
        for(int i=0;i<word1.size();i++)
        {
            s+=word1[i];
        }
        for(int i=0;i<word2.size();i++)
        {
            k+=word1[i];
        }for(int i=0;i<word1.size();i++)
        {
            if(s[i]==k[i])
                flag=1;
            else
                flag=0;break;
        }if(flag=-1)return true;
        else return false;
        
    }
};