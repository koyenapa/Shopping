// https://leetcode.com/problems/maximum-matching-of-players-with-trainers

class Solution {
public:
    int matchPlayersAndTrainers(vector<int>& players, vector<int>& trainers) {
        sort(players.begin(),players.end());
        sort(trainers.begin(),trainers.end());
        int m=players.size(),n=trainers.size();
        
        int i=m-1;int j=n-1;int ans=0;
        
        while(i>=0 && j>=0)
        {
            if(players[i]>trainers[j])i--;
            else{
                ans++;
                i--;
                j--;
            }
        }return ans;
            
    }
        
};