// https://leetcode.com/problems/maximum-matching-of-players-with-trainers

class Solution {
public:
    int matchPlayersAndTrainers(vector<int>& players, vector<int>& trainers) {
        int m=INT_MIN;int count=0;
        for(int i=0;i<players.size();i++)
        {
            if(players[i]==players[i+1])continue;
            for(int j=0;j<trainers.size();j++)
            {
                if(players[i]<=trainers[j])
                {
                    count++;
                    break;
                }
            }m=max(m,count);
        }
        return m;
        
    }
};